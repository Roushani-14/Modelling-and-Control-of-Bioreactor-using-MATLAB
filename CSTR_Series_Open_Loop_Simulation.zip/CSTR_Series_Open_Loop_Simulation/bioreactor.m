function y=bioreactor(t,B,D,Sf)

Yxs=0.4;
beta=0.2;
Pm=50;
Ki=22;
alpha=2.2;
um=0.48;
Km=1.2;

usp=um*(1-B(3)/Pm)*(B(2))/(Km+B(2)+(B(2)*B(2)/Ki));
y(1)=-D*B(1)+usp*B(1);
y(2)=D*(Sf-B(2))*usp*B(1)/Yxs;
y(3)=-D*B(3)+((alpha*usp)+beta)*B(1);

y=y';
