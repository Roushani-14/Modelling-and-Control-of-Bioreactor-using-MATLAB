clear all
clc

SetGraphics;
%QUESTION 1
%STATE VARIABLES /CONTROL VARIABLES X(biomass) , S(substrate) , P(product)
%manipulate D
%disturbance variable Sf

%initial conditions

Sf(1)=20;
D(1)=0.202;
B_initial=[1,2,3];

% Question 2 : To obtain steady state concentration


for i=1:1:500
[t,B] = ode45(@bioreactor,[0 1], B_initial ,[], D(1) , Sf(1));

B_profile(i,1) = B(end,1);                            
B_profile(i,2) = B(end,2); 
B_profile(i,3) = B(end,3);


Time_profile(i,1) = i;

B_initial =  [B_profile(end,1), B_profile(end,2),B_profile(end,3)]; 
end

B_ss = [B_profile(end,1), B_profile(end,2),B_profile(end,3)];

figure(1)

subplot(3,1,1), plot(Time_profile(:),B_profile(:,1),'b'), xlabel('Time'), ylabel('Biomass')
subplot(3,1,2), plot(Time_profile(:),B_profile(:,2),'b'), xlabel('Time'), ylabel('Substrate')
subplot(3,1,3), plot(Time_profile(:),B_profile(:,3),'b'), xlabel('Time'), ylabel('Product')

% Question 3:To obtain step response data 

for i = 1:1:1000

if  i<= 150

D(i)  = D(1);     

Sf(i)  = Sf(1);     

elseif i> 150 && i<=250

D(i)  =0.03*D(1);      

Sf(i)  =0.03*Sf(1);      

elseif i> 250 &&  i<=350

D(i)  = 0.06*D(1);        

Sf(i)  =0.06*Sf(1);          


elseif i> 350 &&  i<=450

D(i)  = -0.06*D(1);        

Sf(i)  =-0.06*Sf(1);          


elseif i>450 &&  i<=550

D(i)  = -0.03*D(1);        
Sf(i)  =-0.03*Sf(1);         


elseif i> 550 &&  i<=650

D(i)  = 0.25*D(1);       

Sf(i)  =0.25*Sf(1);         


elseif i> 650 &&  i<=750

D(i)  = 0.40*D(1);         

Sf(i)  =0.40*Sf(1);         


elseif i> 750 &&  i<=850

D(i)  = -0.25*D(1);        

Sf(i)  =-0.25*Sf(1);         


elseif i>850

D(i)  = -0.40*D(1);         

Sf(i)  =-0.40*Sf(1);          

end
end

figure(2)

subplot(2,1,1),plot(1:1000,D(:),'b'), xlabel('Time'), ylabel('Manipulated variable (D)')
subplot(2,1,2),plot(1:1000,Sf(:),'b'), xlabel('Time'), ylabel('Disturbance variable (Sf)')

% Question 4:Noise generation to add in the measurements

for i = 1:1:500

    wk1(i) = 0.02*randn;
    
end

% Carrying out dynamic simulation for change in the input variable

B_initial2 = B_ss;       

for i = 1:1:500

[t,B] = ode45(@bioreactor,[0 1],B_initial2,[],D(i),Sf(i)) ;

B_step_profile(i,1) = B(end,1)+wk1(i);                   
B_step_profile(i,2) = B(end,2) + wk1(i);         

B_step_profile(i,3) = B(end,3) + wk1(i); 

Time_step_profile(i,1) = i;

B_initial2 =  [B(end,1), B(end,2) , B(end,3)];                 

end

figure(3)

subplot(5,1,1), plot(Time_profile(:),B_step_profile(:,1),'b'), xlabel('Time'), ylabel('Biomass')
subplot(5,1,2), plot(Time_profile(:),B_step_profile(:,2),'b'), xlabel('Time'), ylabel('Substrate')
subplot(5,1,3), plot(Time_profile(:),B_step_profile(:,3),'b'), xlabel('Time'), ylabel('Product')
subplot(5,1,4),plot(1:1000,D(:),'b'), xlabel('Time'), ylabel('Manipulated variable (D)')
subplot(5,1,5),plot(1:1000,Sf(:),'b'), xlabel('Time'),ylabel('Disturbance variable (Sf)')


save Open_Loop_Simulation_Data_CSTR




